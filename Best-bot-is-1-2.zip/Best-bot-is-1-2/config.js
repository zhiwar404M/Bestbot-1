
exports.PREFIX = "b>";
exports.OWNER_ID = "853263207997112340";
exports.Owner_Name = "<@853263207997112340>";
//////////
